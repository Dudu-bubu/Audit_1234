import os
from src.docx_parser import extract_docx_blocks
from src.id_extractor import extract_requirements_with_text
from src.chunker import chunk_blocks
from src.traceability_engine import TraceabilityEngine
from src.gpt_validator import GPTValidator
from src.report_generator import generate_traceability_report


INPUT_DIR = "input_docs"
OUTPUT_FILE = "output/Traceability_Report.docx"

AZURE_ENDPOINT = "https://YOUR_RESOURCE.openai.azure.com/"
AZURE_KEY = "YOUR_KEY"
GPT_DEPLOYMENT = "gpt-4o"


# 1. Load Main Document
main_blocks = extract_docx_blocks(os.path.join(INPUT_DIR, "main.docx"))
requirements = extract_requirements_with_text(main_blocks)

print(f"✅ Extracted {len(requirements)} Requirements from Main.docx")


# 2. Load Supporting Docs + Chunk
supporting_docs = ["urs.docx", "frs.docx", "sds.docx"]

all_chunks = []
chunk_sources = []

for doc_name in supporting_docs:
    blocks = extract_docx_blocks(os.path.join(INPUT_DIR, doc_name))
    chunks = chunk_blocks(blocks)

    all_chunks.extend(chunks)
    chunk_sources.extend([doc_name] * len(chunks))

print(f"✅ Indexed {len(all_chunks)} Supporting Chunks")


# 3. Build Traceability Engine
engine = TraceabilityEngine(all_chunks, chunk_sources)

validator = GPTValidator(
    endpoint=AZURE_ENDPOINT,
    api_key=AZURE_KEY,
    deployment=GPT_DEPLOYMENT
)


# 4. Run Validation
results = []

for req in requirements:

    req_id = req["id"]
    req_text = req["text"]

    match, method = engine.find_match(req_id, req_text)

    if method == "Exact":
        status = "Covered"
        comment = "Exact requirement ID found."
    else:
        gpt_result = validator.validate(req_text, match["chunk"])
        status = gpt_result["status"]
        comment = gpt_result["comment"]

    results.append({
        "id": req_id,
        "status": status,
        "doc": match["doc"],
        "comment": comment,
        "evidence": match["chunk"]
    })


# 5. Generate Word Report
generate_traceability_report(results, OUTPUT_FILE)

print("🎉 Traceability Pipeline Completed Successfully")
