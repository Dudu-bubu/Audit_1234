import re

REQ_PATTERN = r"([A-Z0-9\-]+-(URS|FRS|SDS)\.\d{2}\.\d{3})"


def extract_requirements_with_text(blocks):
    """
    Extract requirement IDs along with nearby description text.
    Returns list of dicts:
      {id, text}
    """

    requirements = []

    for i, block in enumerate(blocks):
        match = re.search(REQ_PATTERN, block)

        if match:
            req_id = match.group(1)

            # Take surrounding text as description
            context = block

            # Add next paragraph if exists
            if i + 1 < len(blocks):
                context += "\n" + blocks[i + 1]

            requirements.append({
                "id": req_id,
                "text": context.strip()
            })

    return requirements
