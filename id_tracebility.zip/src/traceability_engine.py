from src.local_embeddings import embed_text
from src.faiss_index import build_faiss_index, search_index


class TraceabilityEngine:

    def __init__(self, chunks, chunk_sources):
        self.chunks = chunks
        self.chunk_sources = chunk_sources

        # Exact lookup dictionary
        self.exact_lookup = {}
        for chunk, doc in zip(chunks, chunk_sources):
            self.exact_lookup.setdefault(doc, []).append(chunk)

        print("🔄 Creating embeddings...")
        self.vectors = [embed_text(c) for c in chunks]

        print("🔄 Building FAISS index...")
        self.index = build_faiss_index(self.vectors)

        print("✅ Traceability Engine Ready")

    def exact_match(self, req_id):
        """
        Search for exact ID string inside chunks.
        """
        for chunk, doc in zip(self.chunks, self.chunk_sources):
            if req_id in chunk:
                return {
                    "doc": doc,
                    "chunk": chunk,
                    "score": 1.0
                }
        return None

    def semantic_match(self, requirement_text, top_k=3):
        """
        FAISS semantic search fallback.
        """
        query_vec = embed_text(requirement_text)

        scores, indices = search_index(self.index, query_vec, top_k)

        best_idx = indices[0]
        return {
            "doc": self.chunk_sources[best_idx],
            "chunk": self.chunks[best_idx],
            "score": float(scores[0])
        }

    def find_match(self, req_id, req_text):
        """
        Hybrid Match: Exact → Semantic
        """
        exact = self.exact_match(req_id)
        if exact:
            return exact, "Exact"

        semantic = self.semantic_match(req_text)
        return semantic, "Semantic"
