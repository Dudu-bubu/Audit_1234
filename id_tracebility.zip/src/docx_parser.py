from docx import Document


def extract_docx_blocks(file_path):
    """
    Extract all paragraphs + table rows from a DOCX document.
    Returns list of text blocks.
    """
    doc = Document(file_path)
    blocks = []

    # Extract paragraphs
    for p in doc.paragraphs:
        if p.text.strip():
            blocks.append(p.text.strip())

    # Extract tables
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells)
            if row_text.strip():
                blocks.append(row_text)

    return blocks
