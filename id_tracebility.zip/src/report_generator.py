from docx import Document


def generate_traceability_report(results, output_path):

    doc = Document()
    doc.add_heading("Traceability Validation Report", level=1)

    table = doc.add_table(rows=1, cols=5)
    table.style = "Table Grid"

    hdr = table.rows[0].cells
    hdr[0].text = "Requirement ID"
    hdr[1].text = "Status"
    hdr[2].text = "Document"
    hdr[3].text = "Recommendation"
    hdr[4].text = "Evidence"

    for r in results:
        row = table.add_row().cells
        row[0].text = r["id"]
        row[1].text = r["status"]
        row[2].text = r["doc"]
        row[3].text = r["comment"]

        # Evidence snippet (first 200 chars)
        row[4].text = r["evidence"][:200] + "..."

    doc.save(output_path)
    print(f"✅ Report Generated: {output_path}")
