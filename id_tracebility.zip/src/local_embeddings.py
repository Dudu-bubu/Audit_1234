from sentence_transformers import SentenceTransformer

# High accuracy embedding model
MODEL_NAME = "BAAI/bge-base-en-v1.5"

print("🔄 Loading embedding model...")
embedding_model = SentenceTransformer(MODEL_NAME)
print("✅ Model Loaded Successfully")


def embed_text(text):
    """
    Convert text into vector embedding.
    """
    return embedding_model.encode(text, normalize_embeddings=True)
