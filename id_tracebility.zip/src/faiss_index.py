import faiss
import numpy as np
import os


def build_faiss_index(vectors):
    dim = len(vectors[0])
    index = faiss.IndexFlatIP(dim)
    index.add(np.array(vectors).astype("float32"))
    return index


def save_index(index, path="faiss_store/index.bin"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    faiss.write_index(index, path)
    print(f"✅ FAISS Index Saved: {path}")


def load_index(path="faiss_store/index.bin"):
    if os.path.exists(path):
        print("✅ Loading Existing FAISS Index...")
        return faiss.read_index(path)
    return None


def search_index(index, query_vector, top_k=3):
    query_vector = np.array([query_vector]).astype("float32")
    distances, indices = index.search(query_vector, top_k)
    return distances[0], indices[0]
