def chunk_blocks(blocks, chunk_size=3):
    """
    Combine blocks into chunks for semantic indexing.
    """
    chunks = []
    for i in range(0, len(blocks), chunk_size):
        chunk_text = "\n".join(blocks[i:i + chunk_size])
        chunks.append(chunk_text)

    return chunks
