import json
from openai import AzureOpenAI


class GPTValidator:

    def __init__(self, endpoint, api_key, deployment):
        self.client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version="2024-02-15-preview"
        )
        self.deployment = deployment

    def validate(self, main_req_text, candidate_text):
        """
        Validate if candidate requirement satisfies the main requirement.
        """

        prompt = f"""
You are a compliance traceability analyst.

Main Requirement:
{main_req_text}

Candidate Supporting Requirement:
{candidate_text}

Task:
Decide whether the candidate satisfies the main requirement.

Return ONLY JSON:

{{
  "status": "Covered" or "Partial" or "Missing",
  "comment": "Short compliance recommendation"
}}
"""

        response = self.client.chat.completions.create(
            model=self.deployment,
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )

        raw = response.choices[0].message.content.strip()

        try:
            return json.loads(raw)
        except:
            return {
                "status": "Partial",
                "comment": "GPT response could not be parsed cleanly."
            }
