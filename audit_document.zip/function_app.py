
"""
Single Function App with Multiple Functions
- HTTP triggers for API endpoints
- Service Bus trigger for background processing
- No FastAPI wrapping
"""

import io
import json
import logging
import os
import uuid
from datetime import datetime

import azure.functions as func
from azure.storage.blob import BlobServiceClient
from werkzeug.datastructures import FileStorage
from werkzeug.formparser import parse_form_data

# Import processing modules
from backend.core.audit_logic import verify_checkpoints_with_ai
from backend.core.checkpoint_loader import load_checkpoints_from_blob
from backend.core.document_extractor import extract_text_with_docintelligence
from backend.core.logger import log_upload, load_upload_logs
from backend.core.report_generator import generate_report


# Create clean Function App (no FastAPI)
app = func.FunctionApp()

# Environment variables
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")
SERVICE_BUS_CONN_STR = os.getenv("AZURE_SERVICE_BUS_CONN_STR")
SERVICE_BUS_QUEUE = os.getenv("SERVICE_BUS_QUEUE", "audit-queue")

if not BLOB_CONN_STR:
    logging.error("AZURE_BLOB_CONN_STR is not set")

blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)


# ============================================
# HTTP FUNCTIONS (API Endpoints)
# ============================================

@app.function_name(name="UploadDocument")
@app.route(route="audit/run", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
async def upload_document(req: func.HttpRequest) -> func.HttpResponse:
    """Upload a document and queue it for audit processing.

    Expects a multipart/form-data body with a single field:
      - file: PDF or DOCX file to process
    """
    try:
        # Parse multipart form-data manually
        environ = {
            "wsgi.input": io.BytesIO(req.get_body()),
            "CONTENT_LENGTH": str(len(req.get_body())),
            "CONTENT_TYPE": req.headers.get("Content-Type"),
            "REQUEST_METHOD": "POST",
        }
        stream, form, files = parse_form_data(environ)

        file: FileStorage = files.get("file")
        if not file:
            return func.HttpResponse(
                json.dumps({"error": "Missing file"}),
                status_code=400,
                mimetype="application/json",
            )

        filename = file.filename
        if not filename.lower().endswith((".pdf", ".docx")):
            return func.HttpResponse(
                json.dumps({"error": "Only PDF and DOCX are supported"}),
                status_code=400,
                mimetype="application/json",
            )

        file_content = file.stream.read()

        # Continue with blob upload and Service Bus logic
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        file_id = f"{timestamp}_{uuid.uuid4().hex[:8]}"

        blob_name = f"uploads/{file_id}_{filename}"
        blob_client = container_client.get_blob_client(blob_name)
        blob_client.upload_blob(file_content, overwrite=True)
        blob_url = blob_client.url

        # Log upload (ensure logger.log_upload no longer requires 'user')
        log_upload(file_name=filename)

        # Send message to Service Bus for async processing
        from azure.servicebus import ServiceBusClient, ServiceBusMessage

        servicebus_client = ServiceBusClient.from_connection_string(
            SERVICE_BUS_CONN_STR
        )
        sender = servicebus_client.get_queue_sender(SERVICE_BUS_QUEUE)

        message_data = {
            "file_id": file_id,
            "filename": filename,
            "blob_container": BLOB_CONTAINER,
            "blob_name": blob_name,
            "blob_url": blob_url,
            "timestamp": timestamp,
        }
        sender.send_messages(ServiceBusMessage(json.dumps(message_data)))
        sender.close()
        servicebus_client.close()

        # Return a processing status to allow UI to show loading
        return func.HttpResponse(
            json.dumps(
                {
                    "status": "processing",
                    "message": "File uploaded and queued for processing",
                    "file_id": file_id,
                    "blob_url": blob_url,
                }
            ),
            status_code=202,  # Accepted
            mimetype="application/json",
        )
    except Exception as err:
        logging.exception(f"Upload failed: {err}")
        return func.HttpResponse(
            json.dumps({"error": str(err)}),
            status_code=500,
            mimetype="application/json",
        )


@app.function_name(name="ViewReport")
@app.route(
    route="report/view/{file_id}", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def view_report(req: func.HttpRequest) -> func.HttpResponse:
    """Return detailed results as JSON for a given file ID."""
    try:
        file_id = req.route_params.get("file_id")
        if not file_id:
            return func.HttpResponse(
                json.dumps({"error": "Missing file_id"}),
                status_code=400,
                mimetype="application/json",
            )

        blob_name = f"results/results_{file_id}.json"
        blob_client = container_client.get_blob_client(blob_name)
        if not blob_client.exists():
            # Keep original behavior (404) so callers know not ready yet
            return func.HttpResponse(
                json.dumps({"error": "Results not found"}),
                status_code=404,
                mimetype="application/json",
            )

        results_data = json.loads(blob_client.download_blob().readall())
        return func.HttpResponse(
            json.dumps(results_data),
            status_code=200,
            mimetype="application/json",
        )
    except Exception as err:
        logging.exception(f"View report failed: {err}")
        return func.HttpResponse(
            json.dumps({"error": str(err)}),
            status_code=500,
            mimetype="application/json",
        )


@app.function_name(name="DownloadReport")
@app.route(
    route="report/download/{file_id}",
    methods=["GET"],
    auth_level=func.AuthLevel.ANONYMOUS,
)
def download_report(req: func.HttpRequest) -> func.HttpResponse:
    """Download the generated report (.docx) for a given file ID."""
    try:
        file_id = req.route_params.get("file_id")
        if not file_id:
            return func.HttpResponse(
                json.dumps({"error": "Missing file_id"}),
                status_code=400,
                mimetype="application/json",
            )

        blob_name = f"reports/report_{file_id}.docx"
        blob_client = container_client.get_blob_client(blob_name)
        if not blob_client.exists():
            return func.HttpResponse(
                json.dumps({"error": "Report not found"}),
                status_code=404,
                mimetype="application/json",
            )

        file_bytes = blob_client.download_blob().readall()
        return func.HttpResponse(
            body=file_bytes,
            status_code=200,
            mimetype=(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            headers={
                "Content-Disposition": (
                    f"attachment; filename=VSR_{file_id}.docx"
                )
            },
        )
    except Exception as err:
        logging.exception(f"Download report failed: {err}")
        return func.HttpResponse(
            json.dumps({"error": str(err)}),
            status_code=500,
            mimetype="application/json",
        )


@app.function_name(name="GetDashboard")
@app.route(
    route="report/dashboard", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def get_dashboard(req: func.HttpRequest) -> func.HttpResponse:
    """Return the upload history dashboard (all logs)."""
    try:
        logs_data = load_upload_logs()
        data = logs_data
        return func.HttpResponse(
            json.dumps({"dashboard": data}),
            status_code=200,
            mimetype="application/json",
        )
    except Exception as err:
        logging.exception(f"Dashboard failed: {err}")
        return func.HttpResponse(
            json.dumps({"error": str(err)}),
            status_code=500,
            mimetype="application/json",
        )


@app.function_name(name="HealthCheck")
@app.route(route="health", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint."""
    return func.HttpResponse(
        json.dumps(
            {
                "status": "healthy",
                "service": "BD Audit Automation",
                "timestamp": datetime.utcnow().isoformat(),
            }
        ),
        status_code=200,
        mimetype="application/json",
    )


# ============================================
# Status Endpoint: checks whether results blob exists for given file_id
# ============================================

@app.function_name(name="CheckStatus")
@app.route(
    route="report/status/{file_id}", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def check_status(req: func.HttpRequest) -> func.HttpResponse:
    """Return processing status and availability for a given file ID."""
    try:
        file_id = req.route_params.get("file_id")
        if not file_id:
            return func.HttpResponse(
                json.dumps({"error": "Missing file_id"}),
                status_code=400,
                mimetype="application/json",
            )

        results_blob = f"results/results_{file_id}.json"
        report_blob = f"reports/report_{file_id}.docx"

        results_client = container_client.get_blob_client(results_blob)
        report_client = container_client.get_blob_client(report_blob)

        results_exists = results_client.exists()
        report_exists = report_client.exists()

        status = "completed" if results_exists else "processing"

        # Optional hint for UI
        if not results_exists:
            progress_hint = "Processing your file. This may take a few minutes..."
        else:
            progress_hint = "Results are ready. You can view or download the report."

        payload = {
            "status": status,
            "file_id": file_id,
            "results_blob": results_blob,
            "report_blob": report_blob,
            "reportAvailable": report_exists,
            "progressHint": progress_hint,
        }
        return func.HttpResponse(
            json.dumps(payload),
            status_code=200,  # Always 200; status field indicates readiness
            mimetype="application/json",
        )
    except Exception as err:
        logging.exception(f"Status check failed: {err}")
        return func.HttpResponse(
            json.dumps({"error": str(err)}),
            status_code=500,
            mimetype="application/json",
        )


# ============================================
# SERVICE BUS FUNCTION (Background Processing)
# ============================================

@app.function_name(name="ProcessAuditMessage")
@app.service_bus_queue_trigger(
    arg_name="msg",
    queue_name=SERVICE_BUS_QUEUE,
    connection="AZURE_SERVICE_BUS_CONN_STR",
)
async def process_audit_message(msg: func.ServiceBusMessage):
    """Service Bus triggered function to process documents asynchronously."""
    try:
        # Parse message
        raw = msg.get_body()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        data = json.loads(raw)
        logging.info(f"[ProcessAuditMessage] Received: {data}")

        file_id = data.get("file_id")
        blob_name = data.get("blob_name")
        filename = data.get("filename")

        if not all([file_id, blob_name, filename]):
            logging.error(f"Invalid message format: {data}")
            return

        # Download file from blob
        blob_client = container_client.get_blob_client(blob_name)
        if not blob_client.exists():
            logging.error(f"Blob not found: {blob_name}")
            return

        logging.info(f"Downloading blob: {blob_name}")
        file_bytes = blob_client.download_blob().readall()
        ext = filename.lower().split(".")[-1] if filename else ""

        # Extract text
        full_text = None
        try:
            logging.info("Extracting text from document")
            full_text = extract_text_with_docintelligence(file_bytes, ext)
            logging.info(
                "Extraction successful, length: %s",
                len(full_text) if full_text else 0,
            )
        except Exception as extraction_err:
            logging.exception(f"Text extraction failed: {extraction_err}")

        # Load checkpoints
        checkpoints = []
        try:
            logging.info("Loading checkpoints")
            checkpoints = load_checkpoints_from_blob()
            logging.info("Loaded %d checkpoints", len(checkpoints))
        except Exception as load_err:
            logging.exception(f"Loading checkpoints failed: {load_err}")

        # Verify with AI
        results = []
        try:
            logging.info("Starting AI verification")
            results = await verify_checkpoints_with_ai(
                checkpoints, full_text, file_bytes, ext
            )
            logging.info("Verification completed, %d results", len(results))
        except Exception as ai_err:
            logging.exception(f"AI verification failed: {ai_err}")

        # Generate summary (no username)
        summary = {
            "total_checkpoints": len(checkpoints),
            "passed": sum(1 for r in results if r.get("Status") == "Pass"),
            "failed": sum(1 for r in results if r.get("Status") == "Fail"),
            "filename": filename,
        }

        # Generate and upload report
        try:
            logging.info("Generating Word report")
            report_buf = generate_report(filename, summary, results)
            report_path = f"reports/report_{file_id}.docx"
            container_client.upload_blob(
                report_path, report_buf.getvalue(), overwrite=True
            )
            logging.info(f"Report uploaded: {report_path}")
        except Exception as report_err:
            logging.exception(f"Report generation failed: {report_err}")

        # Upload results JSON (no username)
        try:
            results_json = {
                "file_id": file_id,
                "filename": filename,
                "summary": summary,
                "results": results,
                "timestamp": datetime.utcnow().isoformat(),
                "blob_name": blob_name,
            }
            results_path = f"results/results_{file_id}.json"
            container_client.upload_blob(
                results_path, json.dumps(results_json, indent=2), overwrite=True
            )
            logging.info(f"Results uploaded: {results_path}")
        except Exception as upload_err:
            logging.exception(f"Uploading results failed: {upload_err}")

        logging.info("Processing completed for file_id=%s", file_id)
    except json.JSONDecodeError as json_err:
        logging.exception(f"Invalid JSON in message: {json_err}")
    except Exception as err:
        logging.exception(f"Unexpected error: {err}")