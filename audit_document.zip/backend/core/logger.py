# backend/core/logger.py
import os
import json
from datetime import datetime
from azure.storage.blob import BlobServiceClient
import logging

# Environment variables
AZURE_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")
LOG_BLOB_NAME = "logs/upload_logs.json"

# Initialize Blob Service
blob_service = BlobServiceClient.from_connection_string(AZURE_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

def log_upload(file_name: str):
    """Append a new upload log to Azure Blob Storage."""
    try:
        blob_client = container_client.get_blob_client(LOG_BLOB_NAME)

        # Fetch existing logs
        logs_data = []
        if blob_client.exists():
            stream = blob_client.download_blob()
            logs_data = json.loads(stream.readall())

        # Append new log
        new_log = {
            "File_Name": file_name,
            "Upload_Time": datetime.now().isoformat()
        }
        logs_data.append(new_log)

        # Upload updated logs
        blob_client.upload_blob(json.dumps(logs_data), overwrite=True)
    except Exception as e:
        logging.error(f"Error logging upload: {e}")
       


def load_upload_logs():
    """Load all upload logs from Azure Blob Storage."""
    try:
        blob_client = container_client.get_blob_client(LOG_BLOB_NAME)
        if blob_client.exists():
            stream = blob_client.download_blob()
            logs_data = json.loads(stream.readall())
            return logs_data
        else:
            return []
    except Exception as e:
        print(f" Error loading logs: {e}")
        return []