

import os
import pandas as pd
from azure.storage.blob import BlobServiceClient
from io import BytesIO

def load_checkpoints_from_blob(container_name: str = "genaipoc", blob_name: str = "Rules_for_Audit_Automation_version2.xlsx") -> list:
    """
    Load checkpoint descriptions from an Excel file stored in Azure Blob Storage.
    :param container_name: Name of the blob container
    :param blob_name: Name of the blob (Excel file)
    :return: List of checkpoint descriptions
    """
    connection_string = os.getenv("AZURE_BLOB_CONN_STR")
    if not connection_string:
        raise RuntimeError("AZURE_STORAGE_CONNECTION_STRING not set in environment variables.")

    try:
        # Connect to Blob Storage
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service_client.get_container_client(container_name)
        blob_client = container_client.get_blob_client(blob_name)

        # Download blob content into memory
        blob_data = blob_client.download_blob().readall()
        excel_file = BytesIO(blob_data)

        # Read Excel into DataFrame
        df = pd.read_excel(excel_file)
        if "checkpointDesc" not in df.columns:
            raise ValueError("Excel must have 'checkpointDesc' column")

        return df["checkpointDesc"].dropna().tolist()

    except Exception as e:
        # Fallback default rules if blob is not accessible
        print(f"Error loading checkpoints from blob: {e}")
        return [
            "Document should have BD logo",
            "Document should contain project name",
            "Document should have proper page numbering",
            "Document should have SRA information",
            "Document should follow proper formatting guidelines"
        ]