# backend/core/report_generator.py


from docx import Document as DocxDocument
from docx.shared import RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from io import BytesIO
from datetime import datetime

def _set_column_widths(table, widths_in_inches):
    """Set column widths for a table. Requires table.style='Table Grid' and table.autofit=False."""
    table.autofit = False
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            if idx < len(widths_in_inches):
                cell.width = Inches(widths_in_inches[idx])

def generate_report(document_name: str, summary: dict, results: list):
    report = DocxDocument()

    # Title
    title = report.add_heading("Document Validation Report", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Document info
    report.add_paragraph(f"Document: {document_name}")
    report.add_paragraph(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Summary Section
    report.add_heading("Summary", level=1)
    report.add_paragraph(f"Total Checkpoints: {summary['total_checkpoints']}")
    report.add_paragraph(f"Passed: {summary['passed']}")
    report.add_paragraph(f"Failed: {summary['failed']}")

    # Detailed Results Table
    report.add_heading("Detailed Results", level=1)
    table = report.add_table(rows=1, cols=4)
    table.style = "Table Grid"  # Adds borders
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header row
    hdr = table.rows[0].cells
    hdr[0].text = "S.No"
    hdr[1].text = "Checkpoint"
    hdr[2].text = "Status"
    hdr[3].text = "Recommendation"

    # Make header bold
    for cell in hdr:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True

    # Populate rows with dynamic serial numbers
    for idx, r in enumerate(results, start=1):
        row_cells = table.add_row().cells
        row_cells[0].text = str(idx)
        row_cells[1].text = r.get("Checkpoint", "")
        row_cells[2].text = r.get("Status", "")
        row_cells[3].text = r.get("Recommendation", "")

        # Color coding for Status
        try:
            if r.get("Status") == "Pass":
                row_cells[2].paragraphs[0].runs[0].font.color.rgb = RGBColor(0, 128, 0)
            else:
                row_cells[2].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 0, 0)
        except Exception:
            pass

    # Set column widths: make S.No narrow
    # S.No = 0.6", Checkpoint = 2.5", Status = 1.0", Recommendation = 3.5"
    _set_column_widths(table, [0.6, 2.5, 1.0, 3.5])

    # Save to buffer
    buf = BytesIO()
    report.save(buf)
    buf.seek(0)
    return buf
