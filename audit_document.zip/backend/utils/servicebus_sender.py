# backend/utils/servicebus_sender.py

import json

import os

from azure.servicebus import ServiceBusClient, ServiceBusMessage
 
SERVICE_BUS_CONN_STR = os.getenv("AZURE_SERVICE_BUS_CONN_STR")

SERVICE_BUS_QUEUE = os.getenv("SERVICE_BUS_QUEUE")
 
if not SERVICE_BUS_CONN_STR or not SERVICE_BUS_QUEUE:

    # don't raise here — allow code to import but fail clearly when trying to send

    pass
 
def send_message_to_queue(message_dict: dict):

    """

    Send a JSON message to the configured Service Bus queue.

    Raises Exception on failure.

    """
    print("DEBUG: Entered send_message_to_queue")
    print("DEBUG: message_dict =", message_dict)
    print("DEBUG: SERVICE_BUS_CONN_STR =", SERVICE_BUS_CONN_STR)
    print("DEBUG: SERVICE_BUS_QUEUE =", SERVICE_BUS_QUEUE)
    if not SERVICE_BUS_CONN_STR or not SERVICE_BUS_QUEUE:

        raise RuntimeError("Service bus connection string or queue name not configured in env (AZURE_SERVICE_BUS_CONN_STR or SERVICE_BUS_QUEUE).")
 
    sb_client = ServiceBusClient.from_connection_string(SERVICE_BUS_CONN_STR, logging_enable=True)

    with sb_client:

        sender = sb_client.get_queue_sender(queue_name=SERVICE_BUS_QUEUE)

        with sender:

            payload = json.dumps(message_dict)

            msg = ServiceBusMessage(payload)

            sender.send_messages(msg)

 